
O presente ficheiro constitui uma refer�ncia para a elabora��o das apresenta��es no �mbito de Projecto e Semin�rio da LEIC.

Este ficheiro foi elaborado em LaTeX com o package beamer.



CCLEIC,
Abril de 2015.
 