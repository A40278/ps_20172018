
O presente conjunto de ficheiros constitui uma refer�ncia para a elabora��o dos relat�rios de progresso, 
beta e final no �mbito de Projecto e Semin�rio da LEIC.

Este ficheiro foi elaborado usando a distribui��o MIKTEX 2.9,
http://en.wikipedia.org/wiki/MiKTeX
http://miktex.org/2.9/setup
usando o editor TeXnicCenter
http://www.texniccenter.org/

Existem v�rios outros editores que podem ser usados, tais como por exemplo:

	TeXstudio,  http://texstudio.sourceforge.net/
	TeXworks,   https://www.tug.org/texworks/
	ShareLaTeX, https://www.sharelatex.com/
	Texmaker,   http://www.xm1math.net/texmaker/
	LaTeX Lab,  https://code.google.com/p/latex-lab/
	TeX Writer, http://www.texwriterapp.com/

CCLEIC,
Abril de 2015.


