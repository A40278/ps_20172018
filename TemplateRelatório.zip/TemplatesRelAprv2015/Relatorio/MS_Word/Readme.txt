
O presente ficheiro constitui uma refer�ncia para a elabora��o dos relat�rios de progresso, 
beta e final no �mbito de Projecto e Semin�rio da LEIC.

Este ficheiro foi elaborado no MS Word2010.


CCLEIC,
Abril de 2015.
